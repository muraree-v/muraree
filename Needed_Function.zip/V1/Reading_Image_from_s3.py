#Reading image dynamically
import numpy as np
s3 = boto3.client("s3")
bucket_name = "zetasquare"
# fetching object from bucket
file_obj = s3.get_object(Bucket=bucket_name, Key='sachin/fnma/6-1.png' )
# reading the file content in bytes
file_content = file_obj["Body"].read()

# creating 1D array from bytes data range between[0,255]
np_array = np.frombuffer(file_content, np.uint8)
# decoding array
image_np = cv2.imdecode(np_array, cv2.IMREAD_COLOR)
gray = cv2.cvtColor(image_np, cv2.COLOR_BGR2GRAY)
cv2.imwrite(r"E:\base_code\gray_obj.jpg", gray)


