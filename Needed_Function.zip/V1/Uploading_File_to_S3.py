#Uploading file in any place in s3
import boto3
session = boto3.Session() # I assume you know how to provide credentials etc.
s3 = session.client('s3')

bucket = s3.create_bucket('zetasquare')
response = s3.put_object(Bucket='zetasquare', Key='sachin/') # note the ending "/"