
try:
    from PIL import Image
except ImportError:
    import Image
import pytesseract

def ocr_core_tesseract(filename):
    """
    This function will handle the core OCR processing of images.
    """
    from PIL import Image  
    ###print (pytesseract.image_to_string(Image.open('D:/1test/tesseract/01.png')))
    import pytesseract
#    pytesseract.pytesseract.tesseract_cmd = r"c:\users\admin\.virtualenvs\ocr_server-t_ky8s62\lib\site-packages"
    text = pytesseract.image_to_string(filename)  # We'll use Pillow's Image class to open the image and pytesseract to detect the string in the image
    return text
