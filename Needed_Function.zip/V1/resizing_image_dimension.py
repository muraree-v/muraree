import cv2
def resizing_image_dimension(file):
    img = cv2.imread(file, cv2.IMREAD_UNCHANGED)
     
    print('Original Dimensions : ',img.shape)
     
    scale_percent = 60 # percent of original size
    width = 1080
    height = 1080
    dim = (width, height)
    # resize image
    resized = cv2.resize(img, dim, interpolation = cv2.INTER_AREA)
     
    print('Resized Dimensions : ',resized.shape)
     
    cv2.imwrite(file, resized)
