#creating folder in s3
import boto3
from boto3 import client, resource
s3_client = boto3.client('s3')
class S3Helper:

    def __init__(self):
        self.client = client("s3")
        self.s3 = resource('s3')

    def create_folder(self, path):
        path_arr = path.rstrip("/").split("/")
        if len(path_arr) == 1:
            return self.client.create_bucket(Bucket=path_arr[0])
        parent = path_arr[0]
        bucket = self.s3.Bucket(parent)
        status = bucket.put_object(Key="/".join(path_arr[1:]) + "/")
        return status

s3 = S3Helper()
s3.create_folder("zetasquare/Peri")
#s3_client.upload_file(r"E:\flaskV8.1\app.py","zetasquare", '%s/%s' % ("Peri","app.py"))

