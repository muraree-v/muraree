from django.urls import path
from first_app import views

app_name = 'first_app'

urlpatterns = [
    path("",views.index,name="index"),
    path("base/",views.base,name="base"),
    path("other/",views.other,name="other"),
    path("about/",views.about,name="about"),
    path("register/",views.register,name="register"),
    path("login/",views.user_login,name="user_login"),
]
